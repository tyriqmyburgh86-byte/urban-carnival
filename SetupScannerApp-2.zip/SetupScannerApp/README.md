# Setup Scanner: Android app

This folder turns the scanner web page (`www/index.html`) into a real Android app (APK) using Capacitor.
It adds: real Android notifications for new setups and trade alerts, a screen that stays on while the app is open, and native networking (no browser CORS problems).

## Easiest way: let GitHub build the APK for you (free, nothing to install)

1. Create a free account at github.com and make a **new repository** (private is fine).
2. Upload everything in this folder to the repository root, keeping the structure:
   `package.json`, `capacitor.config.json`, `.gitignore`, `www/index.html`, and `.github/workflows/build-apk.yml`.
   On a computer: Add file → Upload files, then drag the whole folder contents in.
   (The hidden `.github` folder must be uploaded too, or the build will not run.)
3. Open the **Actions** tab. If asked, enable workflows. Open **Build Android APK** and press **Run workflow**.
4. Wait about 5 to 8 minutes. Open the finished run and download the **SetupScanner-APK** artifact (a zip containing `app-debug.apk`).
5. Copy `app-debug.apk` to your phone, open it, and allow "Install unknown apps" for your file manager or browser when Android asks.
6. Open the app and allow notifications when asked.

This is a debug APK, which is fine for installing on your own phone. Publishing on the Play Store needs a signed release build.

## Build it yourself instead (computer with Node 20+, Java 17 and Android Studio)

```
npm install
npx cap add android
npx cap sync android
npx cap open android      # then Build > Build APK(s) in Android Studio
```
Or from the command line: `cd android && ./gradlew assembleDebug`.
The APK is created at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Changing the app later
Replace `www/index.html` with your updated page, push it to GitHub (or run `npx cap sync android`), and build again.
Change the app name or ID in `capacitor.config.json` (`appName`, `appId`).

## Limits to know about
- Alerts only work while the app is open or recently in the background. Android pauses web pages in the background after a while, so the scanner can stop checking if the app is closed or the phone sleeps. Keep the app open on screen (the app keeps the screen awake for you). True always-on background scanning needs a foreground service or a server, which is a bigger change.
- Tap the screen once after opening so the alert sound is allowed to play.
- Data: Gold through Binance/Bybit needs no key. US30 needs a Twelve Data API key (Settings).
- This is an analysis and alert tool. It does not place trades. Not financial advice.
